import React from "react";
import QrScanner from "./QrScanner";

const Scanner: React.FC = () => {
  return (
    
    
    <div className="Scanner">
      <center>
        <br></br>
      <QrScanner />
      </center>
    </div>
    
   
  );
};

export default Scanner;
